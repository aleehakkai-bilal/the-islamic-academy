import 'package:flutter/material.dart';

const green = Color(0xFF075B3A);
const gold = Color(0xFFB8860B);

void main() => runApp(const IslamicAcademyApp());

class IslamicAcademyApp extends StatelessWidget {
  const IslamicAcademyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'The Islamic Academy',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        scaffoldBackgroundColor: const Color(0xFFF8FAF8),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;

  final items = const [
    ('قرآن مجید', 'Quran', Icons.menu_book),
    ('نماز سیکھیں', 'Learn Salah', Icons.mosque),
    ('وضو سیکھیں', 'Learn Wudu', Icons.water_drop),
    ('دعائیں و اذکار', 'Duas & Azkar', Icons.volunteer_activism),
    ('احادیث', 'Ahadith', Icons.auto_stories),
    ('سیرت النبی ﷺ', 'Seerah', Icons.person),
    ('تعلیمی ویڈیوز', 'Educational Videos', Icons.play_circle_fill),
    ('کوئز', 'Quiz', Icons.quiz),
    ('گیلری', 'Gallery', Icons.photo_library),
    ('لائبریری', 'Library', Icons.library_books),
    ('نیوز', 'News', Icons.newspaper),
    ('پیغامات', 'Messages', Icons.chat),
  ];

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      const ClassesPage(),
      const MessagesPage(),
      const AlertsPage(),
      const ProfilePage(),
    ];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'ہوم / Home'),
          NavigationDestination(icon: Icon(Icons.school), label: 'کلاسز / Classes'),
          NavigationDestination(icon: Icon(Icons.chat), label: 'پیغامات / Messages'),
          NavigationDestination(icon: Icon(Icons.notifications), label: 'الرٹس / Alerts'),
          NavigationDestination(icon: Icon(Icons.person), label: 'پروفائل / Profile'),
        ],
      ),
    );
  }

  Widget _home() => CustomScrollView(slivers: [
    SliverAppBar(
      pinned: true, backgroundColor: green, foregroundColor: Colors.white,
      title: const Text('The Islamic Academy'),
      actions: [
        IconButton(icon: const Icon(Icons.login), onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage()));
        }),
      ],
    ),
    SliverToBoxAdapter(child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        Image.asset('assets/logo.png', height: 105),
        const SizedBox(height: 8),
        const Text('علم حاصل کریں، عمل کریں، اور کامیاب بنیں\nLearn, Practice and Succeed',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        _banner(Icons.menu_book, 'آج کا سبق / Today’s Lesson', 'نماز کے فرائض اور واجبات'),
        _banner(Icons.newspaper, 'تازہ خبریں / Latest News', 'اکیڈمی کے اہم اعلانات اور تعلیمی خبریں'),
        const SizedBox(height: 10),
        const Align(alignment: Alignment.centerRight,
          child: Text('اہم حصے / Main Sections',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
      ]),
    )),
    SliverPadding(
      padding: const EdgeInsets.all(12),
      sliver: SliverGrid(
        delegate: SliverChildBuilderDelegate(
          (_, i) => Card(child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => ContentPage(title: '${items[i].$1} / ${items[i].$2}'))),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              CircleAvatar(backgroundColor: const Color(0xFFE7F1EC),
                child: Icon(items[i].$3, color: green)),
              const SizedBox(height: 7),
              Text(items[i].$1, textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              Text(items[i].$2, textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 10)),
            ]),
          )),
          childCount: items.length,
        ),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3, crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: .88),
      ),
    ),
  ]);

  Widget _banner(IconData icon, String title, String subtitle) => Card(
    child: ListTile(
      leading: Icon(icon, color: green), title: Text(title),
      subtitle: Text(subtitle), trailing: const Icon(Icons.arrow_forward_ios, size: 15),
    ),
  );
}

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});
  @override Widget build(BuildContext context) {
    final roles = [
      ('طالب علم / Student', Icons.school, 'student'),
      ('استاد / Teacher', Icons.person, 'teacher'),
      ('والدین / Parent', Icons.family_restroom, 'parent'),
      ('پرنسپل / Principal', Icons.manage_accounts, 'principal'),
      ('ایڈمن / Admin', Icons.admin_panel_settings, 'admin'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('لاگ اِن / Login')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Image.asset('assets/logo.png', height: 110),
        const SizedBox(height: 10),
        const Text('اپنے اکاؤنٹ کی قسم منتخب کریں\nSelect your account type',
          textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 15),
        ...roles.map((r) => Card(child: ListTile(
          leading: Icon(r.$2, color: green), title: Text(r.$1),
          trailing: const Icon(Icons.arrow_forward_ios, size: 16),
          onTap: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => LoginFormPage(role: r.$1, type: r.$3))),
        ))),
      ]),
    );
  }
}

class LoginFormPage extends StatelessWidget {
  final String role, type;
  const LoginFormPage({super.key, required this.role, required this.type});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(role)),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      TextField(decoration: const InputDecoration(labelText: 'User ID / صارف نمبر', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      TextField(obscureText: true, decoration: const InputDecoration(labelText: 'Password / پاس ورڈ', border: OutlineInputBorder())),
      const SizedBox(height: 18),
      FilledButton.icon(
        onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (_) => RoleDashboard(type: type, role: role))),
        icon: const Icon(Icons.login), label: const Text('Login / لاگ اِن')),
      const SizedBox(height: 10),
      TextButton(onPressed: () {}, child: const Text('Forgot Password? / پاس ورڈ بھول گئے؟')),
    ]),
  );
}

class RoleDashboard extends StatelessWidget {
  final String type, role;
  const RoleDashboard({super.key, required this.type, required this.role});

  @override Widget build(BuildContext context) {
    final List<Widget> cards = switch (type) {
      'student' => [
        _card(context, 'میری کلاس / My Class', Icons.school, const ClassesPage()),
        _card(context, 'ہوم ورک / Homework', Icons.assignment, const SimplePage(title: 'ہوم ورک / Homework')),
        _card(context, 'امتحانات / Exams', Icons.fact_check, const SimplePage(title: 'امتحانات / Exams')),
        _card(context, 'نتائج / Results', Icons.bar_chart, const SimplePage(title: 'نتائج / Results')),
        _card(context, 'حاضری / Attendance', Icons.event_available, const SimplePage(title: 'حاضری / Attendance')),
        _card(context, 'سرٹیفکیٹس / Certificates', Icons.workspace_premium, const SimplePage(title: 'سرٹیفکیٹس / Certificates')),
      ],
      'teacher' => [
        _card(context, 'طلباء / Students', Icons.groups, const SimplePage(title: 'طلباء / Students')),
        _card(context, 'حاضری / Attendance', Icons.event_available, const SimplePage(title: 'حاضری / Attendance')),
        _card(context, 'ہوم ورک / Homework', Icons.assignment, const SimplePage(title: 'ہوم ورک / Homework')),
        _card(context, 'امتحانات / Exams', Icons.fact_check, const SimplePage(title: 'امتحانات / Exams')),
        _card(context, 'والدین کو نوٹ / Parent Note', Icons.send, const MessageComposerPage(target: 'Parent')),
        _card(context, 'نتائج / Results', Icons.bar_chart, const SimplePage(title: 'نتائج / Results')),
      ],
      'parent' => [
        _card(context, 'میرے بچے / My Child', Icons.child_care, const SimplePage(title: 'میرے بچے / My Child')),
        _card(context, 'حاضری / Attendance', Icons.event_available, const SimplePage(title: 'حاضری / Attendance')),
        _card(context, 'کارکردگی / Performance', Icons.bar_chart, const SimplePage(title: 'کارکردگی / Performance')),
        _card(context, 'ہوم ورک / Homework', Icons.assignment, const SimplePage(title: 'ہوم ورک / Homework')),
        _card(context, 'اساتذہ کو نوٹ / Note to Teacher', Icons.edit_note, const MessageComposerPage(target: 'Teacher / Principal')),
        _card(context, 'پیغامات / Messages', Icons.chat, const MessagesPage()),
      ],
      _ => [
        _card(context, 'طلباء / Students', Icons.groups, const SimplePage(title: 'طلباء / Students')),
        _card(context, 'اساتذہ / Teachers', Icons.school, const SimplePage(title: 'اساتذہ / Teachers')),
        _card(context, 'نیوز / News', Icons.newspaper, const SimplePage(title: 'نیوز / News')),
        _card(context, 'نوٹیفکیشن / Notifications', Icons.notifications, const AlertsPage()),
        _card(context, 'رپورٹس / Reports', Icons.assessment, const SimplePage(title: 'رپورٹس / Reports')),
      ],
    };

    return Scaffold(
      appBar: AppBar(title: Text(role)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(color: const Color(0xFFE7F1EC), child: const Padding(
          padding: EdgeInsets.all(16),
          child: Text('Welcome / خوش آمدید\nThe Islamic Academy',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        )),
        const SizedBox(height: 12),
        ...cards,
      ]),
    );
  }

  Widget _card(BuildContext context, String title, IconData icon, Widget page) =>
    Card(child: ListTile(
      leading: CircleAvatar(backgroundColor: const Color(0xFFE7F1EC), child: Icon(icon, color: green)),
      title: Text(title), trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
    ));
}

class MessageComposerPage extends StatefulWidget {
  final String target;
  const MessageComposerPage({super.key, required this.target});
  @override State<MessageComposerPage> createState() => _MessageComposerPageState();
}
class _MessageComposerPageState extends State<MessageComposerPage> {
  final controller = TextEditingController();
  bool urgent = false;
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('نوٹ / Note to ${widget.target}')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      DropdownButtonFormField<String>(
        value: widget.target,
        decoration: const InputDecoration(labelText: 'Recipient / وصول کنندہ', border: OutlineInputBorder()),
        items: [widget.target, 'Principal / پرنسپل', 'Class Teacher / کلاس ٹیچر']
          .toSet().map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
        onChanged: (_) {},
      ),
      const SizedBox(height: 12),
      TextField(controller: controller, maxLines: 7,
        decoration: const InputDecoration(
          labelText: 'Message / پیغام یا شکایت لکھیں',
          hintText: 'صرف متعلقہ شخص کو یہ پیغام اور الرٹ موصول ہوگا۔',
          border: OutlineInputBorder())),
      SwitchListTile(
        value: urgent, onChanged: (v) => setState(() => urgent = v),
        title: const Text('فوری الرٹ / Urgent Alert'),
        subtitle: const Text('صرف وصول کنندہ کے لیے Push Notification'),
      ),
      FilledButton.icon(
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('پیغام بھیج دیا گیا / Message sent')));
        },
        icon: const Icon(Icons.send), label: const Text('پیغام بھیجیں / Send Message')),
    ]),
  );
}

class MessagesPage extends StatelessWidget {
  const MessagesPage({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('پیغامات / Messages')),
    body: ListView(children: const [
      ListTile(leading: CircleAvatar(child: Icon(Icons.person)),
        title: Text('کلاس ٹیچر / Class Teacher'),
        subtitle: Text('آپ کے بچے کی کارکردگی کے بارے میں اہم پیغام...'),
        trailing: Icon(Icons.notifications_active)),
      ListTile(leading: CircleAvatar(child: Icon(Icons.admin_panel_settings)),
        title: Text('پرنسپل / Principal'),
        subtitle: Text('اہم اعلان / Important notice'),
        trailing: Icon(Icons.notifications_active)),
    ]),
  );
}

class AlertsPage extends StatelessWidget {
  const AlertsPage({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الرٹس / Notifications')),
    body: ListView(padding: const EdgeInsets.all(12), children: const [
      Card(child: ListTile(
        leading: Icon(Icons.notifications_active, color: gold),
        title: Text('نیا پیغام / New Message'),
        subtitle: Text('صرف متعلقہ صارف کے لیے اطلاع۔'),
      )),
      Card(child: ListTile(
        leading: Icon(Icons.newspaper, color: green),
        title: Text('تازہ خبر / Latest News'),
        subtitle: Text('اکیڈمی کی نئی تعلیمی خبر دستیاب ہے۔'),
      )),
    ]),
  );
}

class ClassesPage extends StatelessWidget {
  const ClassesPage({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('کلاسز / Classes')),
    body: ListView(padding: const EdgeInsets.all(12), children: const [
      Card(child: ListTile(title: Text('اسلامیات / Islamic Studies'), subtitle: Text('12 Lessons'))),
      Card(child: ListTile(title: Text('قرآن مجید / Quran'), subtitle: Text('20 Lessons'))),
      Card(child: ListTile(title: Text('نماز و وضو / Salah & Wudu'), subtitle: Text('8 Lessons'))),
    ]),
  );
}

class ContentPage extends StatelessWidget {
  final String title;
  const ContentPage({super.key, required this.title});
  @override Widget build(BuildContext context) => SimplePage(title: title);
}

class SimplePage extends StatelessWidget {
  final String title;
  const SimplePage({super.key, required this.title});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: Center(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Text(
        'یہ سیکشن اگلے مرحلے میں اصل ڈیٹا، ویڈیوز اور مواد کے ساتھ منسلک ہوگا۔\n\nThis section will be connected to the live database and content in the next phase.',
        textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, height: 1.6)),
    )),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override Widget build(BuildContext context) => const Scaffold(
    body: Center(child: Text('پروفائل / Profile\nGuest User', textAlign: TextAlign.center,
      style: TextStyle(fontSize: 24))),
  );
}
